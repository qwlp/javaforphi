package main;

import lib.Name;
import lib.Register;

public class RegisterApp {

	public static String execute(Name nme, Register reg) {	
		
		return "";
	}
}