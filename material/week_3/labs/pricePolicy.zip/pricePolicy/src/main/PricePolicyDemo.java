package main;
import java.util.ArrayList;

import lib.B1G1PricePolicy;
import lib.DefaultPricePolicy;
import lib.DiscountPricePolicy;
import lib.OrderLine;

public class PricePolicyDemo {

	public static void main(String[] args) {
		var cart = new ArrayList<OrderLine>();
		
		//applying default, buy one get one free, and 50% discount policies
		var milk = new OrderLine("Milk", 100, 3, new DefaultPricePolicy());
		var offerMilk = new OrderLine("Milk", 100, 3, new B1G1PricePolicy());
		var halfMilk = new OrderLine("Milk", 100, 3, new DiscountPricePolicy(50));
		
		//adding to the cart
		cart.add(milk);
		cart.add(offerMilk);
		cart.add(halfMilk);
		
		//displaying polymorphism
		for (OrderLine o : cart) {
			System.out.println(o.getPolicy().getBriefDescription());
			System.out.println(o.getCost());
			System.out.println("");
		}
	}

}
