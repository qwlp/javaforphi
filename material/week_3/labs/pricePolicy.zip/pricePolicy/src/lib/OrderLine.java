package lib;


/**
 * A line on an order has a product id, unit cost, and a quantity ordered, e.g.
 * Baked Beans, 55p, quantity 7. The total price of the order line is calculated 
 * by the getCost() method, which multiplies unit price by quantity.
 * 
 * @author lz, la
 */
public class OrderLine {
	//Fields
	private String id; // the identifier for the item ordered
	private int unitPrice; // price of one item in pence
	private int quantity; // the number of items ordered

	private PricePolicy policy; //the price policy
	
	//Constructors
	/**
	 * Default constructor. Sets the id to an empty string. Price and quantity
	 * are zero. Default price policy set.
	 */
	public OrderLine() {
		this("", 0, 0, new DefaultPricePolicy());
	}

	/**
	 * Constructs an OrderLine with the given id for the item ordered. 
	 * Price and quantity are zero. Default price policy set.
	 * 
	 * @param id the name of the product.
	 */
	public OrderLine(String id) {
		this(id, 0, 0, new DefaultPricePolicy());
	}

	/**
	 * Constructs an OrderLine with the given values for id, unit price and
	 * quantity ordered.
	 * 
	 * @param id the name of the product.
	 * @param unitPrice the price of a single product.
	 * @param quantity the quantity of the product to be ordered.
	 * @param polocy the price policy to apply to this order line
	 */
	public OrderLine(String id, int unitPrice, int quantity, PricePolicy policy) {
		this.id = id;
		this.unitPrice = unitPrice;
		this.quantity = quantity;
		this.policy = policy;
	}

	
	//Methods
	/** Sets the item id to the given value. 
	 * 
	 * @param id the name of the product.
	 * */
	public void setId(String id) {
		this.id = id;
	}

	/** Sets the unit price to the given value. 
	 * 
	 * @param unitPrice the price of a single product.
	 * */
	public void setUnitPrice(int unitPrice) {
		this.unitPrice = unitPrice;
	}

	/** Sets the quantity ordered to the given value. 
	 * 
	 * @param quantity the quantity of the product to be ordered.
	 */
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	/** Returns the identifier for the items ordered. 
	 * 
	 * @return the identifier for the items ordered.
	 */
	public String getId() {
		return id;
	}

	/** Returns the price of one item. 
	 * 
	 * @return the price of a single product.
	 */
	public int getUnitPrice() {
		return unitPrice;
	}

	/** Returns the number of items ordered. 
	 * 
	 * @return the number of items ordered.
	 */
	public int getQuantity() {
		return quantity;
	}

	
	/** Calculates and returns the cost of the OrderLine. 
	 * Cost is based on the price policy set.
	 * 
	 * @return the total cost of the order line.
	 */
	public double getCost() {
		return policy.calculateCost(quantity, unitPrice);
	}
	
	/** Returns the price policy set for this order line.
	 * 
	 * @return the price policy for this order line.
	 */
	public PricePolicy getPolicy() {
		return policy;
	}
	
	/** Sets the price policy for this order line. 
	 * 
	 * @param policy the price policy to be assigned.
	 */
	public void setPolicy(PricePolicy policy) {
		this.policy = policy;
	}
	
	

	/** Returns a textual representation of the order line. 
	 * 
	 * @return a textual representation of the order line.
	 */
	@Override
	public String toString() {
		return "OrderLine:[id=" + id + ", unit price=" + unitPrice 
				+ ", quantity=" + quantity + "]";
	}
	
	/** Compares this order line to the specified object. The result is true if and 
	 * only if the argument is not null and is an OrderLine object that has the same
	 * unit price, quantity and id as this object.
	 * 
	 * @param obj the object to compare this OrderLine against.
	 * 
	 * @return true if the given object represents a OrderLine equivalent to this order line, false otherwise.
	 */
	@Override
	public boolean equals(Object obj) {
		return (obj instanceof OrderLine other)
				&& this.id.equals(other.id)
				&& this.unitPrice == other.unitPrice
				&& this.quantity == other.quantity;
	}

}
