package lib;

import java.text.DecimalFormat;

/**
 * A price policy that discounts by a given percentage.
 */
public class DiscountPricePolicy implements PricePolicy {

	//fields
	private String briefDescription;
	private double percentage; //0..100
	private double discount; //= 1-(percentage/100)
	private final static DecimalFormat df = new DecimalFormat("0.00"); //decimal formatter shared by by all instances of DiscountPricePolicy 


	//constructors
	/** Constructs a default price policy with description &quot;Discount&quot;
	 * and 0% discount. */
	public DiscountPricePolicy() {
		this("Discount", 0.0);
	}

	/** Constructs a default price policy with description 
	 * &quot;&lt;percentage&gt;% Discount&quot;
	 * @param percentage the percentage discount
	 */
	public DiscountPricePolicy(double percentage) {
		this(df.format(percentage) + "% Discount", percentage);
	}

	public DiscountPricePolicy(String briefDescription, double percentage) {
		this.briefDescription = briefDescription;
		this.percentage = percentage;
		this.discount = 1- (percentage/100);
	}

	//methods
	/** Sets the default policy description to the given string. */
	public void setBriefDescription(String briefDescription) {
		this.briefDescription = briefDescription;
	}

	/** Returns a description of the price policy.
	 *  This description can be used as a tag to advertise the policy.
	 */ 
	@Override
	public String getBriefDescription() {
		return this.briefDescription;
	}

	/**Returns the percentage discount for the policy. 
	 * @return the percentage discount for the policy
	 */
	public double getPercentage() {
		return percentage;
	}

	/** Sets the percentage discount for the policy. 
	 * @param percentage the percentage discount
	 */
	public void setPercentage(double percentage) {
		this.percentage = percentage;
		this.discount = 1- (percentage/100);
	}

	
	@Override
	/** Returns the product of the number of items and the unit price. */
	public double calculateCost(int quantity, int unitPrice) {
		return quantity * unitPrice * this.discount;
	}

	
	@Override
	public String toString() {
		return "DiscountPricePolicy:[briefDescription=" + this.getBriefDescription() +
					",percentage=" + percentage + ", discount=" + discount + "]";
	}
}
