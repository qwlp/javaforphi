package lib;

/**
 * A default price policy that simply computes the quantity times the unit price.
 */
public class DefaultPricePolicy implements PricePolicy {

	//fields
	private String briefDescription;
	
	
	//constructors
	/** Constructs a default price policy with description &quot;Default&quot;. */
	public DefaultPricePolicy() {
		this.briefDescription = "Default";
	}
	
	/** Constructs an instance of a default price policy with the given brief description. */
	public DefaultPricePolicy(String briefDescription) {
		this.briefDescription = briefDescription;
	}
	
	
	//methods
	/** Sets the default policy description to the given string. */
	public void setBriefDescription(String briefDescription) {
		this.briefDescription = briefDescription;
	}
	
	/** Returns a description of the price policy.
	 *  This description can be used as a tag to advertise the policy.
	 */ 
	@Override
	public String getBriefDescription() {
		return this.briefDescription;
	}
	
	
	@Override
	/** Returns the product of the number of items and the unit price. */
	public double calculateCost(int quantity, int unitPrice) {
		return quantity * unitPrice;
	}
	
	
	@Override
	public String toString() {
		return "DefaultPricePolocy:[briefDescription=" + this.getBriefDescription() + "]";
	}


}
