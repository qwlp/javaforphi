package lib;

/**
 * Buy One Get One Free price policy. 
 */
public class B1G1PricePolicy implements PricePolicy {

	//fields
	private String briefDescription;


	//constructors
	/** Constructs a default price policy with description &quot;B1G1&quot;. */
	public B1G1PricePolicy() {
		this.briefDescription = "B1G1";
	}

	/** Constructs an instance of a default price policy with the given brief description. */
	public B1G1PricePolicy(String briefDescription) {
		this.briefDescription = briefDescription;
	}


	//methods
	/** Sets the default policy description to the given string. */
	public void setBriefDescription(String briefDescription) {
		this.briefDescription = briefDescription;
	}

	/** Returns a description of the price policy.
	 *  This description can be used as a tag to advertise the policy.
	 */ 
	@Override
	public String getBriefDescription() {
		return this.briefDescription;
	}


	@Override
	/** 
	 * Applies the Buy One Get One Free policy to the cost calculation.
	 * If the quantity is even then the price per unit is equivalent to half 
	 * the given unit price. If the quantity is odd then one item is costed 
	 * the the unit price, and the rest are effectively at half the unit price. 
	 * */
	public double calculateCost(int quantity, int unitPrice) {
		return (quantity/2) * unitPrice + (quantity%2) * unitPrice; 
	}

	
	@Override
	public String toString() {
		return "B1G1PricePolicy:[briefDescription=" + this.getBriefDescription() + "]";
	}

}


