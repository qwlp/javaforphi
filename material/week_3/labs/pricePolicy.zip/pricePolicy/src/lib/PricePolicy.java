package lib;

/**
 * Interface for a pricing policy that calculates 
 * the cost of a quantity of items based on a given unit price.  
 */
public interface PricePolicy {
	
	/** 
	 * Returns a description of the price policy.
	 * This intention is that the description is brief so that, for example, it 
	 * could be used as an identifier for the policy.
	 */ 
	public String getBriefDescription(); 

	/** Calculates the cost of a quantity of items based on the unit price.	 */
	public double calculateCost(int quantity, int unitPrice); 
	
}
