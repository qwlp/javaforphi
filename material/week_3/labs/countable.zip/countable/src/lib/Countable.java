package lib;


public interface Countable {
	
	public int getCount();
	
	public void increment();
	
	public void decrement();

}
