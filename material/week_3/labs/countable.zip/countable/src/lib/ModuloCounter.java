package lib;
/**
 * A ModuloCounter maintains a count value, which can be
 * incremented and decremented and reset to zero. It also
 * has a modulo value ensuring the count stays within
 * the range 0..modulo-1 by wrapping appropriately.
 * 
 *  @author la/lz
 */
public class ModuloCounter implements Countable {

	private int count;
	private int modulo;
	
	/** Constructs a counter with initial value zero, and modulo 10. */
	public ModuloCounter() {
		this(0, 10);
	}

	/** Constructs a counter with initial value zero, and the given modulo. */
	public ModuloCounter(int modulo) {
		this.count = 0;
		this.modulo = modulo;
	}
	
	/** 
	 * Constructs a counter with an initial value, count, 
	 * to the given modulo. 
	 */
	public ModuloCounter(int count, int modulo) {
		this.count = count % modulo;
		this.modulo = modulo;
	}
	
	public void setModulo(int modulo) {
		this.modulo = modulo;
		this.count = count % modulo;
	}
	
	public void reset() {
		count = 0;
	}
	
	/**Increments the counter by one. 
	 * Wraps to zero when count reaches modulo.
	 */
	public void increment() {
		count = count + 1;
		if (count == modulo) count = 0;
	}
	
	/** Decrements the counter by one, unless it is zero, 
	 *  upon which it wraps to modulo-1. 
	 */
	public void decrement() {
		count = count - 1;
		if (count < 0) count = modulo - 1;
	}
	
	/**
	 * Returns the count value.
	 * @return Returns the count value.<br />
	 * It will be between 0 and modulo-1 inclusive.
	 */
	public int getCount() {
		return count;
	}

	public int getModulo() {
		return modulo;
	}
	
	public boolean isZero() {
		return count==0;
	}
	
	@Override
	public String toString() {
		return this.getClass().getName() + "[count=" + count + ", modulo=" + modulo + "]";
	}
	
}
