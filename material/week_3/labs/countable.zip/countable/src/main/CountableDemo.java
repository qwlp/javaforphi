package main;
import java.util.ArrayList;
import java.util.List;

import lib.Countable;
import lib.Counter;
import lib.ModuloCounter;

public class CountableDemo {

	public static void main(String[] args) {
		List<Countable> counters = new ArrayList<>();
		
		counters.add(new Counter());
		counters.add(new ModuloCounter(0,5));
		
		for (Countable c : counters) {
			System.out.println(c.toString());
			
			for (int i = 0; i < 40; i++) {
				System.out.print(c.getCount() + " ");
				c.increment();
			}
			
			System.out.println("\n");
			
			
			
		}
		

	}

}
