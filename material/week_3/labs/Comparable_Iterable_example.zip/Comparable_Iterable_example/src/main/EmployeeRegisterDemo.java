package main;

import lib.employeeRegister.Date;
import lib.employeeRegister.Employee;
import lib.employeeRegister.EmployeeRegister;
import lib.employeeRegister.Name;

public class EmployeeRegisterDemo {

	public static void main(String[] args) {
		var reg = new EmployeeRegister("Finance");
		
		reg.addEmployee(new Employee(new Name("Anna", "Holdon"), new Date(1,3,2009), 10000));
		reg.addEmployee(new Employee(new Name("Tom", "Ford"), new Date(5,5,2013), 15500.50));	
		reg.addEmployee(new Employee(new Name("Katie", "Wood"), new Date(4,1,2010), 25000.50));
		reg.addEmployee(new Employee(new Name("Dharmesh", "Palal"), new Date(1,12,2012), 12000));
		
		reg.sortEmployeeRegister();
		
		
		for (Employee e : reg) {
			System.out.println(e.getName().getFullName());
			System.out.println("Salary is " + e.getSalary() + " -- Start date: " + e.getStartDate().getDateString() + "\n");
		}
		
		
	}

}
